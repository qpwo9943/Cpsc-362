# now only first index is the answer need to change
# play again menu
# image?
# in/correct ui
# division deciaml point
# atleast second trial

from tkinter import *
from tkinter.font import Font
from random import *
from PIL import ImageTk, Image

# from time import *
# import threading


win = Tk()
win.geometry("390x846")
bg = Image.open("Start_Screen_BG.png")
resized = bg.resize((390, 846), Image.ANTIALIAS)
bgImage = ImageTk.PhotoImage(resized)
Label(win, image = bgImage).place(relwidth = 1, relheight = 1)

# getting x , y
def click():
    num1 = int(random() * 10 + 1)
    num2 = int(random() * 10 + 1)
    return num1, num2


def destroyMenu():
    btn_addition.destroy()
    btn_subtraction.destroy()
    btn_multiplication.destroy()
    btn_dvision.destroy()
    btn_exit.destroy()


# generating buttons for ans
def ansButton(anslist,questionLabel):
    bt1 = Button(win, text=str(anslist[0]), font="Kranky 38", command=lambda: checkAns(anslist[0]), bd=0)
    bt2 = Button(win, text=str(anslist[1]), font="Kranky 38", command=lambda: checkAns(anslist[1]), bd=0)
    bt3 = Button(win, text=str(anslist[2]), font="Kranky 38", command=lambda: checkAns(anslist[2]), bd=0)
    bt4 = Button(win, text=str(anslist[3]), font="Kranky 38", command=lambda: checkAns(anslist[3]), bd=0)

    bt1.place(x=100, y=340)
    bt2.place(x=230, y=340)
    bt3.place(x=100, y=500)
    bt4.place(x=230, y=500)

    def destroy():
        bt1.destroy()
        bt2.destroy()
        bt3.destroy()
        bt4.destroy()
        questionLabel.destroy()

    # check the answer
    def checkAns(ans):
        destroy()
        if ans == realAns:
            ansLabel = Label(win, text="CORRECT!", font="Kranky 21")
            ansLabel2 = Label(win, text=realAns, font="Kranky 21")
            ansLabel2.place(x=160, y=260)
            ansLabel.place(x=120, y=220)
            btn_continue = Button(win, text="Continue",font="Time 15", padx=35, pady=35, command=lambda: continue_learning())
            btn_exit = Button(win, text="Exit", font="Time 15", padx=35, pady=35, command=win.quit)
            btn_exit.place(x=120, y=420)
            btn_continue.place(x=120, y=330)

            def continue_learning():
                ansLabel.destroy()
                ansLabel2.destroy()
                btn_continue.destroy()
                questionLabel.destroy()
                btn_exit.destroy()
                if arithmetic == "+":
                    addition()
                elif arithmetic == "-":
                    subtraction()
                elif arithmetic == "x":
                    multiplication()
                elif arithmetic == "/":
                    dvision()



        else:
            ansLabel = Label(win, text="Wrong!", font="Kranky 21")
            ansLabel.grid(row=1, column=0)
            btn_continue = Button(win, text="Continue", font="Time 15", padx=35, pady=35, command=lambda: continue_l())
            btn_continue.grid(row=4, column=0)

            def continue_l():
                ansLabel.destroy()
                questionLabel.destroy()
                btn_continue.destroy()
                btn_exit.destroy()
                if arithmetic == "+":
                    addition()
                elif arithmetic == "-":
                    subtraction()
                elif arithmetic == "x":
                    multiplication()
                elif arithmetic == "/":
                    dvision()

# store the followings into list
def storeAns(x, y):
    # print("inside storeAns")
    # print("arithmetic: " + arithmetic)
    anslist = []
    ans_inList = False
    global realAns

    if arithmetic == "+":
        realAns = x + y
        for index in range(4):
            ans = int(random() * 10)
            anslist.append(ans)
            if anslist[index] == realAns:
                ans_inList = True
                print("answer already in the list")
            print(anslist[index])

        print("correct answer ", realAns)
        i = randint(0, 3)
        print(" index = ", i)

        if ans_inList == False:
            anslist[i] = realAns
        print(anslist[i])
    elif arithmetic == "-":
        realAns = x - y
        for index in range(4):
            ans = int(random() * 10)
            anslist.append(ans)
            if anslist[index] == realAns:
                ans_inList = True
                print("answer already in the list")
            print(anslist[index])

        print("correct answer " , realAns )
        i = randint(0, 3)
        print(" index = ",i )

        if ans_inList == False:
            anslist[i] = realAns
        print(anslist[i])
    elif arithmetic == "x":
        realAns = x * y
        for index in range(4):
            ans = int(random() * 10)
            anslist.append(ans)
            if anslist[index] == realAns:
                ans_inList = True
                print("answer already in the list")
            print(anslist[index])

        print("correct answer " , realAns )
        i = randint(0, 3)
        print(" index = ",i )

        if ans_inList == False:
            anslist[i] = realAns
        print(anslist[i])
    elif arithmetic == "/":
        realAns = x / y
        for index in range(4):
            ans = int(random() * 10)
            anslist.append(ans)
            if anslist[index] == realAns:
                ans_inList = True
                print("answer already in the list")
            print(anslist[index])

        print("correct answer " , realAns )
        i = randint(0, 3)
        print(" index = ",i )

        if ans_inList == False:
            anslist[i] = realAns
        print(anslist[i])
    return anslist


def addition():
    global arithmetic
    arithmetic = "+"
    destroyMenu()
    # 2개의 번호생성 ex 9+5
    x, y = click()
    questionLabel = Label(win, text="{0} + {1} = __".format(x, y), font="Kranky 38")
    questionLabel.place(x=90, y=260)
    z = storeAns(x, y)
    ansButton(z,questionLabel)


def subtraction():
    global arithmetic
    arithmetic = "-"
    destroyMenu()
    # 2개의 번호생성 ex 9+5
    x, y = click()
    questionLabel = Label(win, text="{0} - {1} = __".format(x, y), font="Kranky 38")
    questionLabel.place(x=90, y=260)
    z = storeAns(x, y)
    ansButton(z,questionLabel)


def multiplication():
    global arithmetic
    arithmetic = "x"
    destroyMenu()
    # 2개의 번호생성 ex 9+5
    x, y = click()
    questionLabel = Label(win, text="{0} x {1} = __".format(x, y), font="Kranky 38")
    questionLabel.place(x=90, y=260)
    z = storeAns(x, y)
    ansButton(z,questionLabel)


def dvision():
    global arithmetic
    arithmetic = "/"
    destroyMenu()
    # 2개의 번호생성 ex 9+5
    x, y = click()
    questionLabel = Label(win, text="{0} / {1} = __".format(x, y), font="Kranky 38") #can we add a function where it only gives whole numbers
    questionLabel.place(x=90, y=260)
    z = storeAns(x, y)
    ansButton(z,questionLabel)

#Addition button
addIG = Image.open("Plus_Icon.png")
addRes = addIG.resize((41, 38), Image.ANTIALIAS)
addim = ImageTk.PhotoImage(addRes)
btn_addition = Button(win, image=addim, command=addition, borderwidth=0)
btn_addition.place(x=100, y=300)


#Subtraction Button
subIG = Image.open("Sub_Icon.png")
subRes = subIG.resize((62, 10), Image.ANTIALIAS)
subim = ImageTk.PhotoImage(subRes)
btn_subtraction = Button(win, image=subim, command=subtraction, borderwidth=0)
btn_subtraction.place(x=230, y=310)

#Multiplication Button
mulIG = Image.open("Mul_Icon.png")
mulRes = mulIG.resize((41, 38), Image.ANTIALIAS)
mulim = ImageTk.PhotoImage(mulRes)
btn_multiplication = Button(win, image=mulim, command=multiplication, borderwidth=0)
btn_multiplication.place(x=100, y=500)

#Division Button
divIG = Image.open("Div_Icon.png")
divRes = divIG.resize((41, 38), Image.ANTIALIAS)
divim = ImageTk.PhotoImage(divRes)
btn_dvision = Button(win, image=divim, command=dvision, borderwidth=0)
btn_dvision.place(x=230, y=500)


#Exit Button
exIG = Image.open("Start_Screen_Exit_Icon.png")
exRes = exIG.resize((159, 73), Image.ANTIALIAS)
exim = ImageTk.PhotoImage(exRes)
btn_exit = Button(win, image=exim, command=win.quit, borderwidth=0)
btn_exit.place(x=120, y=600)

win.mainloop()
